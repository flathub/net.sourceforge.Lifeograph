QT -= gui

CONFIG += console
CONFIG -= app_bundle

# Qt 5.12 introduces the 'c++17' config option; this sets it manually
QMAKE_CXXFLAGS += -std=c++17

# Since Qt #defines emit, signal, and slot, we need to disable those keywords
CONFIG += no_keywords

# We must link with sigc++-3.0
unix{
    CONFIG += link_pkgconfig
    PKGCONFIG += sigc++-3.0
}

# The following define makes your compiler emit warnings if you use
# any Qt feature that has been marked deprecated (the exact warnings
# depend on your compiler). Please consult the documentation of the
# deprecated API in order to know how to port your code away from it.
DEFINES += QT_DEPRECATED_WARNINGS

# You can also make your code fail to compile if it uses deprecated APIs.
# In order to do so, uncomment the following line.
# You can also select to disable deprecated APIs only up to a certain version of Qt.
#DEFINES += QT_DISABLE_DEPRECATED_BEFORE=0x060000    # disables all the APIs deprecated before Qt 6.0.0

SOURCES += \
        main.cpp \
    exampleclass.cpp

# Default rules for deployment.
qnx: target.path = /tmp/$${TARGET}/bin
else: unix:!android: target.path = /opt/$${TARGET}/bin
!isEmpty(target.path): INSTALLS += target

HEADERS += \
    exampleclass.h
